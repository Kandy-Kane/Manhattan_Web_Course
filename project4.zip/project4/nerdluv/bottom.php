<!-- shared page bottom HTML -->
<div>
    <p>
        This page is for single nerds to meet and date each other! Type in your personal information and wait for the
        nerdly luv to begin! Thank you for using our site.
    </p>

    <p>
        Results and page (C) Copyright NerdLuv Inc.
    </p>

    <ul>
        <li>
            <a href="index.php">
                <img src="images/back.gif" alt="icon"/>
                Back to front page
            </a>
        </li>
    </ul>
</div>

<div id="w3c">
    <a href="https://validator.w3.org/check?uri=https://turing.manhattan.edu/~fkane01/Manhattan_Web_Course/project4/nerdluv/index.php">
        <img src="images/w3c-html.png" alt="Valid HTML"/></a>
    <a href="http://jigsaw.w3.org/css-validator/validator?uri=https://turing.manhattan.edu/~fkane01/Manhattan_Web_Course/project4/nerdluv/nerdluv.css">
        <img src="images/w3c-css.png" alt="Valid CSS"/></a>
</div>
</body>
</html>
