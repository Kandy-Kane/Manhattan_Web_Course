<!--
Frank Kane
Web Programming
HW 4
04/18/21
-->

<?php include("top.php"); ?>

<div>
    <h1>Welcome!</h1>

    <ul>
        <li>
            <a href="signup.php">
                <img src="images/signup.gif" alt="icon"/>
                Sign up for a new account
            </a>
        </li>

        <li>
            <a href="matches.php">
                <img src="images/heartbig.gif" alt="icon"/>
                Check your matches
            </a>
        </li>
    </ul>
</div>

<?php include("bottom.php"); ?>
