<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, initial-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>NerdLuv</title>

    <!-- instructor-provided CSS and JavaScript links; do not modify -->
    <link href="images/heart.gif" type="image/gif" rel="shortcut icon"/>
    <link href="nerdluv.css" type="text/css" rel="stylesheet"/>
</head>

<body>
<div id="bannerarea">
    <img src="images/nerdluv.png" alt="banner logo"/> <br/>
    where meek geeks meet
</div>

<!-- your HTML output follows -->
		